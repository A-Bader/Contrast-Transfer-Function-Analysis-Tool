function [FOV] = computeHorizontalFOV(currentPath,parentImgFolderPath,patternDirection,FOV)

if strcmp(patternDirection, 'Horizontal')==1
    [I,~] = readImagesInFile(currentPath,parentImgFolderPath,1,patternDirection);
    X=  size(I,1);
    NumOfPixelsPerDegree = X/FOV;
    FOV=size(I,2)/NumOfPixelsPerDegree;
end
end