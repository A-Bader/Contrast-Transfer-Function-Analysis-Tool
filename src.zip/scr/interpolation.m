function interpolationValue = interpolation(Crop_X, X_axis_max, Collect_Data_envelope, X_axis_min,I_Slice,ResultedSignal)
display='Off';
% linear interpolation between peaks and bottom points of the smoothed signal
ImgIntervalmax = 1:Crop_X;
MaxOut = interp1(X_axis_max,Collect_Data_envelope(:,3)',ImgIntervalmax,'linear');
MaxOut(isnan(MaxOut)) = 0;

ImgIntervalmin  = 1:Crop_X;%= X_axis_min(1):1:X_axis_min(end);
MinOut = interp1(X_axis_min,Collect_Data_envelope(:,2)',ImgIntervalmin,'linear');
MinOut(isnan(MinOut)) = 1;

show = strcmp(display, 'On');
if show == 1
    figure,
    plot(I_Slice,'-.','LineWidth',1)
    hold on
    plot(ResultedSignal,'.-','LineWidth',1)
    plot(ResultedSignal,'-','LineWidth',1)
    plot(X_axis_max,Collect_Data_envelope(:,3),'o',ImgIntervalmax,MaxOut,':.');
    plot(X_axis_min,Collect_Data_envelope(:,2),'o',ImgIntervalmin,MinOut,':.');
    title('linear Interpolation');
end

sizeData=min(size(MaxOut,2),size(MinOut,2));
interpolationValue=zeros(1,sizeData);
for i=1:sizeData
    Check=MinOut(i)+MaxOut(i);
    if Check>0
        interpolationValue(i)=(MaxOut(1,i)-MinOut(1,i))/(MinOut(1,i)+MaxOut(1,i));
    else
        interpolationValue=0;
    end
end
end