function [CollectContrast] = interpolationValueMidOfImg(interpolationValue)
CollectContrast= interpolationValue(round(end/2));
end