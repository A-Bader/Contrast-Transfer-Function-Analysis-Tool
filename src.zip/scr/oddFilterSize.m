function FilterSize = oddFilterSize(FilterSize)
    FilterSize = round(FilterSize);
    isodd = rem(FilterSize,2) == 1;
    if isodd==0
        FilterSize=FilterSize+1;
    end
end