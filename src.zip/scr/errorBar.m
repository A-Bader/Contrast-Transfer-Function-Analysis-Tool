function [CTF_ErrorBar] = errorBar(interpolationValue,PixelPerCycle,NumOfPixelsPerDegree)
% Compute averaged CTF value surrounded by error bar within a range of window % of 1-2 degrees
WindowDegrees=2;
BeginRange=round(  size(interpolationValue,2)/2   -  (NumOfPixelsPerDegree*(WindowDegrees/2) )  );
EndRange=round  (  size(interpolationValue,2)/2   +  (NumOfPixelsPerDegree*(WindowDegrees/2) )  );
Contrastvalues= interpolationValue( BeginRange:EndRange );

S = std(Contrastvalues);
ContrastValue = mean(Contrastvalues,"all");

CTF_ErrorBar(1)=ContrastValue;
CTF_ErrorBar(2)=S;
CTF_ErrorBar(3)=-S;

end