function [IncreaseCycPerDeg, DecreaseCycPerDeg, IncreaseIndexes, DecreaseIndexes,increaseCounter, decreaseCounter,FlagIncFilterSize, FlagDecFilterSize,StartIncPixelPitch,StartDecPixelPitch] = sortData(pattrenNum, index, collectCyclesPerDegree, IncreaseCycPerDeg, DecreaseCycPerDeg,IncreaseIndexes, DecreaseIndexes,increaseCounter, decreaseCounter,FlagIncFilterSize, FlagDecFilterSize,StartIncPixelPitch,StartDecPixelPitch)

    if index==1
        IncreaseCycPerDeg(index,1)=collectCyclesPerDegree(1,pattrenNum);
        DecreaseCycPerDeg(index,1)=collectCyclesPerDegree(1,pattrenNum);
        increaseCounter=1;
        decreaseCounter=1;
        StartIncPixelPitch=pattrenNum;
        StartDecPixelPitch=pattrenNum;
        IncreaseIndexes(1,:)=[increaseCounter,StartIncPixelPitch,pattrenNum];
        DecreaseIndexes(1,:)=[decreaseCounter,StartDecPixelPitch,pattrenNum];
    else
    
        RowIncFilter= size(IncreaseCycPerDeg,1);
        LastElementIncFilter= size(IncreaseCycPerDeg,2);
        RowDecFilter= size(DecreaseCycPerDeg,1);
        LastElementDecFilter= size(DecreaseCycPerDeg,2);
    
    
        if collectCyclesPerDegree(1,pattrenNum)>collectCyclesPerDegree(1,pattrenNum-1)
            if FlagIncFilterSize==1
                FlagIncFilterSize=1;
                FlagDecFilterSize=0;
                IncreaseCycPerDeg(RowIncFilter,LastElementIncFilter+1)=collectCyclesPerDegree(1,pattrenNum);
                increaseCounter=increaseCounter+1;
                IncreaseIndexes(RowIncFilter,:)=[increaseCounter,StartIncPixelPitch,pattrenNum];
            else
                increaseCounter=2;
                StartIncPixelPitch=pattrenNum-1;
                FlagIncFilterSize=1;
                FlagDecFilterSize=0;
                RowIncFilter=RowIncFilter+1;
                LastElementIncFilter=1;
                IncreaseCycPerDeg(RowIncFilter,LastElementIncFilter)=collectCyclesPerDegree(1,pattrenNum-1);
                IncreaseCycPerDeg(RowIncFilter,LastElementIncFilter+1)=collectCyclesPerDegree(1,pattrenNum);
                IncreaseIndexes(RowIncFilter,:)=[increaseCounter,StartIncPixelPitch,pattrenNum];
            end
    
        elseif collectCyclesPerDegree(1,pattrenNum)<collectCyclesPerDegree(1,pattrenNum-1)
    
            if  FlagDecFilterSize==1
    
                FlagDecFilterSize=1;
                FlagIncFilterSize=0;
                DecreaseCycPerDeg(RowDecFilter,LastElementDecFilter+1)=collectCyclesPerDegree(1,pattrenNum);
                decreaseCounter=decreaseCounter+1;
                DecreaseIndexes(RowDecFilter,:)=[decreaseCounter,StartDecPixelPitch,pattrenNum];
            else
                decreaseCounter=2;
                StartDecPixelPitch=pattrenNum-1;
    
                FlagDecFilterSize=1;
                FlagIncFilterSize=0;
    
                RowDecFilter=RowDecFilter+1;
                LastElementDecFilter=1;
                DecreaseCycPerDeg(RowDecFilter,LastElementDecFilter)=collectCyclesPerDegree(1,pattrenNum-1);
                DecreaseCycPerDeg(RowDecFilter,LastElementDecFilter+1)=collectCyclesPerDegree(1,pattrenNum);
                DecreaseIndexes(RowDecFilter,:)=[decreaseCounter,StartDecPixelPitch,pattrenNum];
            end
    
        elseif collectCyclesPerDegree(1,pattrenNum)==collectCyclesPerDegree(1,pattrenNum-1)
            if FlagIncFilterSize ==1
                RowIncFilter=RowIncFilter+1;
                IncreaseIndexes(RowIncFilter,:)=[1,pattrenNum,pattrenNum];
                FlagIncFilterSize=0;
            end
            if  FlagDecFilterSize==1
                RowDecFilter=RowDecFilter+1;
                DecreaseIndexes(RowDecFilter,:)=[1,pattrenNum,pattrenNum];
                FlagDecFilterSize=0;
            end
        end
    end

end
