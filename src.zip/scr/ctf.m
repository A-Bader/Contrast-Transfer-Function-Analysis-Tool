function  [Avg_black, Avg_White, SD_black, SD_White, collectCyclesPerDegree,collectCTFErrorBar]=ctf(FOV,patternDirection, parentImgFolderPath,smoothSignal,FlatWhiteImages )
                                                                                                    
% Function Arguments
%
% FOV: Field of view in degrees
%
% numberOfPatterns: Number of patterns used excluding black background images
%
% patternDirection: is the white and black lines are in "vertical" or "horizontal"
%
% parentImgFolderPath: path of the parent folder that contian all subfolders of patterns
%
% ImgFolderName: name portion of subfolder without adding number in the end, for example,
% if subfolders are Pattern1, Pattern2, ... then the name only "Pattern".
% The number if the end of subfolder represent the pixel pitch of the lines.
%
% display: "on" it presents the square signal and "off" does not present any of these square figures.
% This to validate the method used in this program
%
% cropPctWidth: Crop percentage of the image width around the center. Used to remove image edges.
%
% numOfPixelsInHeightToAvg: Fixed number of pixels used to take the average of the signal.

format long
currentPath=pwd;

Avg_black=0;
Avg_White=0;
SD_black=0;
SD_White=0;

FlagIncFilterSize=1;
FlagDecFilterSize=1;
increaseCounter=1;
decreaseCounter=1;
StartDecPixelPitch=0;
StartIncPixelPitch=0;
IncreaseFilterSize=-999;
DecreaseFilterSize=-999;
IncreaseIndexes=[0,0,0];
DecreaseIndexes=[0,0,0];

minNoPixelsPerDeg=150;
numOfPixelsInHeightToAvg = 200;
cropPctWidth = 80
subFolderNameContainsImgs='';


clear collectCyclesPerDegree collectMichelsonContrast
% Compute Filter size using Flat White
if smoothSignal == 1
    folder_dir = FlatWhiteImages;

    [Img,className] = readImagesInFile(currentPath,folder_dir,'','','Vertical');
    % figure,
    % imagesc(Img)

    [~, ~, ~, ~, ~, ~, FilterSize] = fourier_trans(folder_dir, FOV,Img);
    FilterSize = oddFilterSize(FilterSize)
else
    FilterSize = 1;
end

 noOfPatterns= numberOfPatterns(parentImgFolderPath,currentPath);
 [FOV] = computeHorizontalFOV(currentPath,parentImgFolderPath,patternDirection,FOV);


% compute number of pixels per cycles
index=0;
largestCycleSize=0;
for pattrenNum=1:noOfPatterns
    Pattern_Number=pattrenNum
    [I,className] = readImagesInFile(currentPath,parentImgFolderPath,subFolderNameContainsImgs,pattrenNum,patternDirection);
    [X, Crop_X, Crop_Y, I_Crop] = cropImage(I,cropPctWidth, numOfPixelsInHeightToAvg);
    I_Slice(pattrenNum,:)=sum(I_Crop,1)/Crop_Y;
    NumOfPixelsPerDegree = round(X/FOV);
    if NumOfPixelsPerDegree<minNoPixelsPerDeg
        f = warndlg(['Warning: Camera resolution is too low. Please increase the number of camera pixels to > 150 per degree'],'Error');
    end
    %Smoothing
    if smoothSignal == 1
        smoothingSignal(pattrenNum,:)=movingAverageFilter(I_Slice(pattrenNum,:),FilterSize);
    else
        smoothingSignal(pattrenNum,:)=I_Slice(pattrenNum,:);
    end
    %Binarize
    [bottomLocations, peakLocations, numberOfPeaks, firstPeaklocation, ~,SizeofFilter] = binarizeSignal(smoothingSignal(pattrenNum,:),'off',className);
    if numberOfPeaks<1
        patternLineSize(pattrenNum)=0;
        continue
    end

    %collect # of pixels per cycle
    [patternLineSize(pattrenNum), Signal_period(:,pattrenNum)] = computeFilterSize(firstPeaklocation, SizeofFilter);

    % sort output data in increase or decrease pattern
    index=index+1;
    [IncreaseFilterSize, DecreaseFilterSize, IncreaseIndexes, DecreaseIndexes,increaseCounter, decreaseCounter,FlagIncFilterSize, FlagDecFilterSize,StartIncPixelPitch,StartDecPixelPitch] = sortData(pattrenNum, index, patternLineSize, IncreaseFilterSize, DecreaseFilterSize,IncreaseIndexes, DecreaseIndexes,increaseCounter, decreaseCounter,FlagIncFilterSize, FlagDecFilterSize,StartIncPixelPitch,StartDecPixelPitch);

    %measuring noise level
    [Avg_black, Avg_White, SD_black, SD_White, largestCycleSize] = noiseLevel( largestCycleSize, numberOfPeaks, bottomLocations, patternLineSize(pattrenNum), I_Crop, Crop_Y, peakLocations, Avg_black, Avg_White, SD_black, SD_White);
end



% compute the smallest filtersize and range of pattern -- based on pixels per cycle
[startPatternNo, endPatternNo, ~] = findContinuousRanges(DecreaseIndexes, IncreaseIndexes)
counter=0;
collectCyclesPerDegree=zeros(1,(endPatternNo-startPatternNo+1));
collectCTFErrorBar=zeros( (endPatternNo-startPatternNo+1),3);
for pattrenNum=startPatternNo:endPatternNo
    [X_axis_max, X_axis_min, Collect_Data_envelope] = dataEnvelope(Signal_period(:,pattrenNum), Crop_X, smoothingSignal(pattrenNum,:));
    interpolationValue = interpolation(Crop_X, X_axis_max, Collect_Data_envelope, X_axis_min,I_Slice(pattrenNum,:),smoothingSignal(pattrenNum,:));
    counter=counter+1;
    collectCyclesPerDegree(counter) = 1/(Signal_period(1,pattrenNum)*FOV/X);
    collectCTFErrorBar(counter,:)= errorBar(interpolationValue,Signal_period(1,pattrenNum),NumOfPixelsPerDegree);
end

% sort output data in increase or decrease pattern (based on Spatial frequency)
clear DecreaseIndexes IncreaseIndexes;
indexCTF=0;

FlagIncFilterSize=1;
FlagDecFilterSize=1;
increaseCounter=1;
decreaseCounter=1;
StartDecPixelPitch=0;
StartIncPixelPitch=0;
IncreaseFilterSize=-999;
DecreaseFilterSize=-999;
IncreaseIndexes=[0,0,0];
DecreaseIndexes=[0,0,0];

for pattrenNum=1:counter
    indexCTF=indexCTF+1;
    [IncreaseFilterSize, DecreaseFilterSize, IncreaseIndexes, DecreaseIndexes,increaseCounter, decreaseCounter,FlagIncFilterSize, FlagDecFilterSize,StartIncPixelPitch,StartDecPixelPitch] = sortData(pattrenNum, indexCTF, patternLineSize(startPatternNo:endPatternNo), IncreaseFilterSize, DecreaseFilterSize,IncreaseIndexes, DecreaseIndexes,increaseCounter, decreaseCounter,FlagIncFilterSize, FlagDecFilterSize,StartIncPixelPitch,StartDecPixelPitch);
end

%collect Data and return final result
[startPatternNo, endPatternNo, ~] = findContinuousRanges(DecreaseIndexes, IncreaseIndexes);
collectCyclesPerDegree=collectCyclesPerDegree(startPatternNo:endPatternNo);
collectCTFErrorBar =collectCTFErrorBar(startPatternNo:endPatternNo,:);

end
