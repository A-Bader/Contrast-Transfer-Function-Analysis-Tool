function [x, L, fx, fft_L, fc, HMD_pixel_pitch, HMD_pixel_pitch_NumImgPix] = fourier_trans(folder_dir, FoV,img)

Nx = size(img,2);
Ny = size(img,1);
ax = FoV/Nx;        % camera pixel pitch in degree

x = 0:(Nx-1);
x = (x-max(x)/2)*ax;    % horizontal x in degree

fx = 0:(Nx-1);
fx = (fx - max(fx)/2)/max(fx)/ax;

L = zeros(200, Nx);
fft_L = zeros(200, Nx);
for i2 = 1:200
    L_temp = img(Ny/2-100+i2,:); % note when size change
    L(i2,:) = L_temp;
    fft_L(i2,:) = fftshift(abs(fft(L_temp)));
end
log_fft_L = mean(log(fft_L));
 
%figure; plot(fx, log_fft_L); 

log_fft_L(fx<2) = 0;
[~, N_fc] = max(log_fft_L);

fc = fx(N_fc);
HMD_pixel_pitch = 1/fc;
HMD_pixel_pitch_NumImgPix = HMD_pixel_pitch/ax;
end