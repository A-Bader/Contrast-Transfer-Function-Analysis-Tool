function [Avg_black, Avg_White, SD_black, SD_White,largetFilterSize,SmallestFilterSize] = noiseLevel( largetFilterSize, numberOfPeaks, bottomLocations, FilterSize, I_Crop, Crop_Y, peakLocations,Avg_black, Avg_White, SD_black, SD_White)
% compute average white and black luminace and return the best fit filter size

if FilterSize>largetFilterSize
    SelectMidOfSignal=round(numberOfPeaks/2);
    StartLocationForBlackRegion= bottomLocations(SelectMidOfSignal);
    %figure,  imagesc(I_Crop); title({'cropped center of the image'},'Color','black');
    % if (2*FilterSize<minimumDisplaytoCamreaPixels)
    %     error('Error. The ratio of pixels between display and camera is small. Must be at least 10 pixels for each dispaly pixel')
    % end
    CropBackgroundBlack =  imcrop(I_Crop,[round(StartLocationForBlackRegion+0.1*FilterSize)  1 round(FilterSize-0.2*FilterSize)   Crop_Y]);
    StartLocationForWhiteRegion= peakLocations(SelectMidOfSignal);
    CropBackgroundWhite =  imcrop(I_Crop,[round(StartLocationForWhiteRegion+0.1*FilterSize)  1 round(FilterSize-0.2*FilterSize)   Crop_Y]);

    % Compute Average and Standard Deviation
    CropBackgroundBlack_1D=reshape(CropBackgroundBlack,[],1);
    CropBackgroundWhite_1D=reshape(CropBackgroundWhite,[],1);
    Avg_black= mean(CropBackgroundBlack_1D);
    Avg_White= mean(CropBackgroundWhite_1D );
    SD_black = std(CropBackgroundBlack_1D );
    SD_White = std(CropBackgroundWhite_1D );
    largetFilterSize=FilterSize;
end

end

 