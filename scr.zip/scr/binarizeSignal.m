function [bottomLocations, peakLocations, numberOfPeaks, firstPeaklocation, lastPeaklocation, SizeofFilter] = binarizeSignal(Img, display, className)
    % Function description 
    %
    % binarizeSignal converts the signal to square wave signal
    %
    
    display = 'Off';

    % Binarize the periodic signal to square wave signal to find the number of peaks and the size in pixels per cycle
    SizeofFilter = 0;

    if strcmp(className, 'uint8')
        level = graythresh(uint8(Img));
        BW = imbinarize(uint8(Img), level);
    end

    if strcmp(className, 'uint16')
        level = graythresh(uint16(Img));
        BW = imbinarize(uint16(Img), level);
    end

    if strcmp(className, 'int16')
        level = graythresh(int16(Img));
        BW = imbinarize(int16(Img), level);
    end

    if strcmp(className, 'single')
        level = graythresh(single(Img));
        BW = imbinarize(single(Img), level);
    end

    if strcmp(className, 'double')
        level = graythresh(double(Img));
        BW = imbinarize(double(Img), level);
    end

    peakLocations = strfind(BW, [0 1]);
    peakLocations = peakLocations(2:end - 1);
    numberOfPeaks = size(peakLocations, 2);

    %if peaks less than 3
    if numberOfPeaks <= 1
        bottomLocations = 0;
        peakLocations = 0;
        numberOfPeaks = 0;
        firstPeaklocation = 0;
        lastPeaklocation = 0;

    else
        SizeofFilter = (peakLocations(end) - peakLocations(1)) / (numberOfPeaks - 1) / 2;

        % Check if square wave signal are preoidic and having same sizes
        differencesBtwnCycles = diff(peakLocations);
        SDOfDiffBtwnCycles = std(differencesBtwnCycles);

        if SDOfDiffBtwnCycles < 10

            bottomLocations = strfind(BW, [1 0]);
            bottomLocations = bottomLocations(1:end - 1);
            peakLocations = strfind(BW, [0 1]);
            numberOfPeaks = size(peakLocations, 2);
            peakLocations = peakLocations(1:end - 1);

            if peakLocations(1) < bottomLocations(1)
                firstPeaklocation = peakLocations(1);
                lastPeaklocation = peakLocations(end);
            else
                firstPeaklocation = bottomLocations(1);
                lastPeaklocation = bottomLocations(end);
            end

            % Plot
            show = strcmp(display, 'On');

            if show == 1
                figure,
                plot(BW, 'k', 'LineWidth', 1)
                ylim([-2 2])
                xlim([0 size((BW), 2)])
            end

        else
            bottomLocations = 0;
            peakLocations = 0;
            numberOfPeaks = 0;
            firstPeaklocation = 0;
            lastPeaklocation = 0;
        end

    end

end
