clear
close all

% ---- Horizontal FOV value --------%
FOV = 15.5;

% ---- Pattern Direction -------- %
% patternDirection = 'Horizontal';
patternDirection = 'Vertical';

% ---- Smoothing signal: --------%
% smoothSignal = 0;
smoothSignal = 1;

% ---- Read acquired images from folder path  -------- %
FlatWhiteImages = 'PATH_TO_FlatWhite_Images';

% ---- Read flat White images from folder path  --------%
parentFolderPath = 'PATH_TO_Acquired_Images';

[Avg_black, Avg_White, SD_black, SD_White, collectCyclesPerDegree, collectCTFErrorBar] = ctf(FOV, patternDirection, parentFolderPath, smoothSignal, FlatWhiteImages);

figure,
hold on
errorbar(collectCyclesPerDegree, collectCTFErrorBar(:, 1)', collectCTFErrorBar(:, 2)', collectCTFErrorBar(:, 3)', 'k', 'LineWidth', 2)
xlabel({'Spatial Frequency (cycles/deg)'}, 'FontWeight', 'bold')
ylabel('CTF', 'FontWeight', 'bold')
ylim([0 1])
xlim([0 ceil(max(collectCyclesPerDegree)) + 0.5])
grid on
