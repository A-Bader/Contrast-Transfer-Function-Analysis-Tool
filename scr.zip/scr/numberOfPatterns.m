function numberOfFolders = NumberOfPatterns(parentImgFolderPath, currentPath)
    % Function description 
    %
    % NumberOfPatterns determines the number of data points based on the number of acquired image subfolders
    % 


    cd (parentImgFolderPath)

    % Specify the directory path
    folderPath = parentImgFolderPath; % Change to your target path

    % Get the list of all items in the directory
    items = dir(folderPath);

    % Filter for folders only (excluding '.' and '..')
    folders = items([items.isdir] & ~ismember({items.name}, {'.', '..'}));

    % Count the number of folders
    numberOfFolders = numel(folders);

    % Display the result
    cd (currentPath)
end
