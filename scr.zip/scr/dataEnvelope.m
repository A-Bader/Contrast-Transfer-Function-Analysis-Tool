function [X_axis_max, X_axis_min, Collect_Data_envelope] = dataEnvelope(Signal_period, Crop_X, ResultedSignal)
    % Function description 
    %
    % connect all peaks and bottoms of the smoothed signal to result data envelope
    %
 
    counter1 = 0;
    clear X_axis_max X_axis_min Collect_Data_envelope

    for i = Signal_period(2, 1):Signal_period(1, 1):Crop_X - Signal_period(1, 1)
        counter1 = counter1 + 1;
        Signal = ResultedSignal(1, i:i + Signal_period(1, 1) - 1);

        [Contrast, Imin, Imax] = michelsonContrast(Signal);
        Collect_Data_envelope(counter1, :) = [Contrast, Imin, Imax];

        MaxIndex = find(ResultedSignal(1, i:i + Signal_period(1, 1) - 1) == Imax) + (i - 1);
        MinIndex = find(ResultedSignal(1, i:i + Signal_period(1, 1) - 1) == Imin) + (i - 1);

        X_axis_max(counter1) = MaxIndex(1);
        X_axis_min(counter1) = MinIndex(1);
    end

    counter1 = counter1 + 1;
    Signal = ResultedSignal(1, i + Signal_period(1, 1):end);
    [Contrast, Imin, Imax] = michelsonContrast(Signal);
    Collect_Data_envelope(counter1, :) = [Contrast, Imin, Imax];
    X_axis_max(counter1) = find(ResultedSignal(i:end) == Imax, 1) + (i - 1);
    X_axis_min(counter1) = find(ResultedSignal(1, i:end) == Imin, 1) + (i - 1);
end
