function [I, className] = readImagesInFile(currentPath, parentImgFolderPath, subFolderNameContainsImgs, pixelPitch, patternDirection)
    % Function description 
    %
    % readImagesInFile reads images from the parent folders and subfolders
    %

    %read all images inside acquired data folder where images must be only of these types 'jpg', 'jpeg', 'png', 'bmp', 'tif';
    ImgFolderName = sprintf('%s%d', subFolderNameContainsImgs, pixelPitch);

    try
        cd (parentImgFolderPath)
    catch
        f = warndlg(['Error: file path ', parentImgFolderPath, ' does not exist.'], 'Error');
        return;
    end

    if (isempty(ImgFolderName) == 0)

        try
            cd (ImgFolderName)
        catch
            f = warndlg(['Error: file name ', ImgFolderName, ' does not exist.'], 'Error');
            return;
        end

    end

    fileList = [dir('*.jpg'); dir('*.jpeg'); dir('*.png'); dir('*.bmp'); dir('*.tif'); ];
    fileNames = sort({fileList.name}');
    nfiles = length(fileNames);
    sumImage = 0;

    for i = 1:nfiles
        currentfilename = char(fileNames(i));
        currentimage = imread(currentfilename);
        className = class(currentimage);
        Hor = strcmp(patternDirection, 'Horizontal');

        if Hor == 1
            %if patternDirection== 'horizontal'
            currentimage = imrotate(currentimage, 90);
        end

        sumImage = sumImage + double(currentimage);
    end

    I = sumImage / nfiles;
    cd (currentPath)
end
