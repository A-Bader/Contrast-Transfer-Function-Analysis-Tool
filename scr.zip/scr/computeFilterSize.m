function [FilterSize, Signal_period] = computeFilterSize(firstPeaklocation, SizeofFilter)
    % Function description 
    %
    % computeFilterSize computes the optimal filter size for moving-average filter 
    %

    % compute filter size which is the half of pixles of a cycle
    FilterSize = SizeofFilter;
    Signal_period = [round(2 * FilterSize); firstPeaklocation];

    %odd filter size
    FilterSize = round(FilterSize);

    isodd = rem(FilterSize, 2) == 1;

    if isodd == 0
        FilterSize = FilterSize - 1;
    end

end
