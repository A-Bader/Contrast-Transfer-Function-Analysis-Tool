function [X, Crop_X, Crop_Y, I_Crop] = cropImage(I, CropPctWidth, NumOfPixelsToAverage)
    % Function description 
    %
    % cropImage crops the image in the middle by predefined values
    %

    [Y, X, ~] = size(I);
    Crop_X = round(CropPctWidth / 100 * X);
    Crop_Y = NumOfPixelsToAverage;

    X_center = round(X / 2);
    Y_center = round(Y / 2);

    Start_pixel_X = X_center - round(Crop_X / 2);
    Start_pixel_Y = Y_center - round(Crop_Y / 2);

    I_Crop = imcrop(I, [Start_pixel_X Start_pixel_Y Crop_X - 1 Crop_Y - 1]);
    [Crop_Y, Crop_X, ~] = size(I_Crop);
end
