function FilterSize = oddFilterSize(FilterSize)
    % Function description 
    %
    % oddFilterSize changes the filter size to odd number only in case if the filter is even
    % 

    FilterSize = round(FilterSize);
    isodd = rem(FilterSize, 2) == 1;

    if isodd == 0
        FilterSize = FilterSize + 1;
    end

end
