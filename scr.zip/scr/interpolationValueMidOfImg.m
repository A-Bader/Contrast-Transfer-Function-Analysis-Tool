function [CollectContrast] = interpolationValueMidOfImg(interpolationValue)
    % Function description 
    %
    % interpolationValueMidOfImg computes mid point value
    % 
    CollectContrast = interpolationValue(round(end / 2));
end
