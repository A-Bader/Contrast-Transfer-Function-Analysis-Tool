function [startPatternNo, endPatternNo, numberOfPatterns] = findContinuousRanges(DecreaseIndexes, IncreaseIndexes)
    % Function description 
    %
    % findContinuousRanges tracks the number of cycles per degrees and excludes any dramatic change in the number of cycles per degree
    % 

    %collect all adjacent CTF for the patterns with acceptable conditions
    [LargestDecRange, NumberofDecPatterns] = max(DecreaseIndexes(:, 1));
    [LargestIncRange, NumberofIncPatterns] = max(IncreaseIndexes(:, 1));

    if LargestDecRange > LargestIncRange
        startPatternNo = DecreaseIndexes(NumberofDecPatterns, 2);
        endPatternNo = DecreaseIndexes(NumberofDecPatterns, 3);
        numberOfPatterns = LargestDecRange;
    else
        startPatternNo = IncreaseIndexes(NumberofIncPatterns, 2);
        endPatternNo = IncreaseIndexes(NumberofIncPatterns, 3);
        numberOfPatterns = LargestIncRange;
    end

end
