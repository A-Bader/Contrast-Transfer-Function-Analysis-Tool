function [Avg_black, Avg_White, SD_black, SD_White, largetFilterSize, SmallestFilterSize] = noiseLevel(largetFilterSize, numberOfPeaks, bottomLocations, FilterSize, I_Crop, Crop_Y, peakLocations, Avg_black, Avg_White, SD_black, SD_White)
    % Function description 
    %
    % noiseLevel computes the average luminance in the white and black areas of the entered images
    % 

    if FilterSize > largetFilterSize
        SelectMidOfSignal = round(numberOfPeaks / 2);
        StartLocationForBlackRegion = bottomLocations(SelectMidOfSignal);
        CropBackgroundBlack = imcrop(I_Crop, [round(StartLocationForBlackRegion + 0.1 * FilterSize) 1 round(FilterSize - 0.2 * FilterSize) Crop_Y]);
        StartLocationForWhiteRegion = peakLocations(SelectMidOfSignal);
        CropBackgroundWhite = imcrop(I_Crop, [round(StartLocationForWhiteRegion + 0.1 * FilterSize) 1 round(FilterSize - 0.2 * FilterSize) Crop_Y]);

        % Compute Average and Standard Deviation
        CropBackgroundBlack_1D = reshape(CropBackgroundBlack, [], 1);
        CropBackgroundWhite_1D = reshape(CropBackgroundWhite, [], 1);
        Avg_black = mean(CropBackgroundBlack_1D);
        Avg_White = mean(CropBackgroundWhite_1D);
        SD_black = std(CropBackgroundBlack_1D);
        SD_White = std(CropBackgroundWhite_1D);
        largetFilterSize = FilterSize;
    end

end
