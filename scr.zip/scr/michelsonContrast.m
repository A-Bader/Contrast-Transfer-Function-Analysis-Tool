function [Contrast, Imin, Imax] = michelsonContrast(Signal)
    % Function description 
    %
    % michelsonContrast computes Michelson Contrast value 
    % 

    
    Imin = min(Signal);
    Imax = max(Signal);

    Check = Imin + Imax;

    if Check > 0
        Contrast = (Imax - Imin) / (Imin + Imax);
    else
        Contrast = 0;
    end

end
