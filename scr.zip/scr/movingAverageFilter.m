function Out = movingAverageFilter(Signal, filterSize)
    % Function description 
    %
    % movingAverageFilter apply the filter on the signal to smooth it
    % 

    % 1-D filter accept only odd number as a filter size
    Size = size (Signal);
    sizeSignal = Size (1, 2);
    filterSize1 = mod (filterSize, 2);
    Out = zeros(1, sizeSignal);

    if isequal (filterSize1, 0)
        error ('Cannot use the filter size as an even number.');
    else
        padSignal = (filterSize - 1) / 2;
        Pad = zeros (1, padSignal);
        newSignal = [Pad Signal Pad];

        for i = 1:sizeSignal
            temp = 0;

            for j = 1:filterSize
                temp = temp + newSignal(i + j - 1);
            end

            Out(i) = temp / filterSize;
        end

    end

end
