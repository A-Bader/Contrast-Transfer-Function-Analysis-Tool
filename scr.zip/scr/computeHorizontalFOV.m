function [FOV] = computeHorizontalFOV(currentPath, parentImgFolderPath, patternDirection, FOV)
    % Function description 
    %
    % computeHorizontalFOV computes the field of view (fov) of the camera to match the entered images which are horizontal grille pattern
    %
    if strcmp(patternDirection, 'Horizontal') == 1
        [I, ~] = readImagesInFile(currentPath, parentImgFolderPath, 1, patternDirection);
        X = size(I, 1);
        NumOfPixelsPerDegree = X / FOV;
        FOV = size(I, 2) / NumOfPixelsPerDegree;
    end

end
